#!/bin/bash

#set -x
echo "matrix, build DAG,build matrix" >> avg.csv
while read matrix
do
  name=`echo $matrix | cut -d',' -f2`
  build_dag=`cat chrono.avg."$name" | head -1 | cut -d: -f2` >> avg.csv
  build_matrix=`cat chrono.avg."$name" | tail -1 | cut -d: -f2` >> avg.csv
  echo "${name},${build_dag},${build_matrix}" >> avg.csv
done < ../matrix.ID.name
#set +x
